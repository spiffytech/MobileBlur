from pymysql.tests.test_issues import *
from pymysql.tests.test_example import *
from pymysql.tests.test_basic import *

if __name__ == "__main__":
    import unittest
    unittest.main()
