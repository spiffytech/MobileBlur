alert("test2.js is loaded from test plugin");
