response.files.append(URL('static','plugin_multiselect/jquery.dimensions.js'))
response.files.append(URL('static','plugin_multiselect/jquery.multiselect.js'))
response.files.append(URL('static','plugin_multiselect/jquery.multiselect.css'))
response.files.append(URL('static','plugin_multiselect/start.js'))
